package src;

import java.awt.*;

public class CircleObject extends CollisionObject{
    //instance variables
    final private double radius;
    final private int r = (int) (Math.random() * 256);
    final private int g = (int) (Math.random() * 256);
    final private int b = (int) (Math.random() * 256);
    Color c = new Color(r,g,b);
    public CircleObject(double xPoint, double yPoint, double radius) {
        super(xPoint, yPoint);
        this.radius = radius;
        setCenter();

    }
    private void setCenter(){
        double xPoint = get_xPoint() - radius;
        double yPoint = get_yPoint() - radius;
        set_xPoint(xPoint);
        set_yPoint(yPoint);
    }

    @Override
    public void drawObject(Graphics2D g2d) {
            //sets circle to randomized color and draws
            g2d.setColor(c);
            g2d.fillOval((int) get_xPoint(), (int) get_yPoint(), (int) radius*2, (int) radius*2);
        }

}
