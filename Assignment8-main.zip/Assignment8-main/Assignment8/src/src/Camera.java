package src;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class Camera implements Drawable, MouseMotionListener {
    //instance variables
    private double x;
    private double y;
    private double radius;

    public Camera(double x, double y, double radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }


    @Override
    public void drawObject(Graphics2D g2d) {
        g2d.setColor(Color.BLUE);
        g2d.fillOval((int) x,(int) y,(int) radius,(int) radius);
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        this.x = e.getX();
        this.y = e.getY();
    }
}
