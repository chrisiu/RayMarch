package src;

import java.awt.*;

public interface Drawable {
    void drawObject(Graphics2D g2d);
}
