package src;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JPanel;

/**
 * Displays and updates the logic for the top-down raymarcher.
 */
public class RaymarcherPanel extends JPanel {
    private ArrayList<CollisionObject> shapeList = new ArrayList<>();
    private Camera camera;
    /**
     * We need to keep a reference to the parent swing app for sizing and 
     * other bookkeeping.
     */
    private final RaymarcherRunner raymarcherRunner;
    
    public RaymarcherPanel(RaymarcherRunner raymarcherRunner) {
        this.raymarcherRunner = raymarcherRunner;
        this.setPreferredSize(new Dimension(this.raymarcherRunner.getFrame().getHeight(), 
                this.raymarcherRunner.getFrame().getHeight()));
        generateRandomShapes();
        camera = new Camera(0,0,10);
        addMouseMotionListener(camera);
        }

    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.GRAY);
        camera.drawObject(g2d);
        drawFromList(g2d);


    }

    private void generateRandomShapes() {
        for (int i = 0; i < 16; i++) {
            double randomY = Math.random() * (this.getPreferredSize().height - 100); //program crashes my GPU if width or
            double randomX = Math.random() * (this.getPreferredSize().width - 100); //height is too big
            if (i % 2 == 0) {
                double randomWidth =  Math.random() * 100;
                double randomHeight = Math.random() * 100;
                RectangleObject randomRectangle = new RectangleObject(randomX, randomY, randomWidth, randomHeight);
                shapeList.add(randomRectangle);
            } else {
                double randomRadius = Math.random() * 100;
                CircleObject randomCircle = new CircleObject(randomX, randomY, randomRadius);
                shapeList.add(randomCircle);
            }

        }
        }
    private void drawFromList(Graphics2D g2d){
        for (CollisionObject c: shapeList){
            c.drawObject(g2d);

        }
    }
}
