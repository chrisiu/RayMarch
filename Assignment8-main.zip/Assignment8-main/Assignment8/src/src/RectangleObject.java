package src;

import java.awt.*;

public class RectangleObject extends CollisionObject{
//instance variables
    private double width;
    private double height;
    final private int r = (int) (Math.random() * 256);
    final private int g = (int) (Math.random() * 256);
    final private int b = (int) (Math.random() * 256);
    Color c = new Color(r,g,b);
    public RectangleObject(double xPoint, double yPoint,double width, double height) {
        super(xPoint, yPoint);
        this.width = width;
        this.height = height;
        setCenter();
    }
    private void setCenter() {
        double xPoint = get_xPoint() - width / 2;
        double yPoint = get_yPoint() - height / 2;
        set_xPoint(xPoint);
        set_yPoint(yPoint);
    }

    @Override
    public void drawObject(Graphics2D g2d) {
        //sets rectangle to a random color and draws
        g2d.setColor(c);
        g2d.fillRect((int) get_xPoint(), (int) get_yPoint(), (int) this.width,(int) this.height);
    }
}
